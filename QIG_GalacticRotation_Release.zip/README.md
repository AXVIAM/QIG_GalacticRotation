# QIG Galactic Rotation
This repository contains the first public validation of Quantum Information Gravity (QIG) as applied to galactic rotation curves, demonstrating accurate reproduction of observed data without the need for dark matter.

## Structure
- `notebooks/`: Python and Jupyter scripts
- `data/`: SPARC and galaxy rotation datasets
- `plots/`: Model vs observational visuals
- `docs/`: The formal release paper

## Author
Christopher P. B. Smolen (AXVIAM)

## License
Open-source under the included license file.
